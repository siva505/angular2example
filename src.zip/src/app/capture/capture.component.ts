import { Component, ViewContainerRef, ViewEncapsulation, OnInit } from '@angular/core';
import {CaptureService} from '../services/capture.service';
import { Modal, BSModalContextBuilder } from 'angular2-modal/plugins/bootstrap';
declare var $: any;
@Component({
  selector: 'app-capture',
  templateUrl: './capture.component.html',
  styleUrls: ['./capture.component.css']
  

})
export class CaptureComponent implements OnInit {
  model: any = {};
  openResult: any;
  openResult1: any;
  


  constructor(vcRef: ViewContainerRef, public modal: Modal,private captureService:  CaptureService) {
   
  }
  
 

  ngOnInit() {
  }


  open(){      
      
      //this.openResult = 
      this.captureService.open(this.model).subscribe((result: any) => {
                                    let res = result;                                    
                                    console.log("suc"+JSON.stringify(res));
                                    this.model = result;
                                    if(result != null){
                                        this.openResult = result;
                                        $("#myModal").modal('show');
                                    }else{
                                         this.openResult = "There is no record exists with this id";
                                         $("#myModal1").modal('show');
                                    }
                                },
                                err => {
                                    console.log(err );
                                }
                         );;
     
    }

  upload(){
      this.captureService.upload(this.model).subscribe((result: any) => {
                                    let res = result;                                    
                                    console.log("suc"+JSON.stringify(res));
                                    this.openResult = result;
                                     $("#myModal1").modal('show');
                                   },
                                err => {
                                    console.log(err );
                                }
                         );;
  }

  refresh(): void {
    window.location.reload();
}

}
