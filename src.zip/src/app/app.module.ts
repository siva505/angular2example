import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AngularDraggableModule } from 'angular2-draggable';
import { FormsModule }   from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { CaptureComponent } from './capture/capture.component';
import { AuthorizeComponent } from './authorize/authorize.component';
import { ModifyComponent } from './modify/modify.component';
import { MainComponent } from './main/main.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import {  HttpModule} from "@angular/http";
import { ModalModule } from 'angular2-modal';
import {CaptureService} from './services/capture.service';
import {AuthorizeService} from './services/authorize.service';
import {ModifyService} from './services/modify.service';
import { BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';

const appRoutes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: MainComponent },
  { path: 'authorizeimages', component: AuthorizeComponent },
  { path: 'modifyimages', component: ModifyComponent },
  { path: 'captureimages', component: CaptureComponent },
  { path: '**', component: MainComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    CaptureComponent,
    AuthorizeComponent,
    ModifyComponent,
    MainComponent,
    HeaderComponent,
    FooterComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ModalModule.forRoot(),
    BootstrapModalModule,
    AngularDraggableModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false } // <-- debugging purposes only
    )
   
  ],
  providers: [CaptureService,AuthorizeService,ModifyService],
  bootstrap: [AppComponent]
})
export class AppModule { }
