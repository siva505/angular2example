import { Component, ViewContainerRef, ViewEncapsulation, OnInit } from '@angular/core';
//import { Component,OnInit } from '@angular/core';
import {ModifyService} from '../services/modify.service';
import { Modal, BSModalContextBuilder } from 'angular2-modal/plugins/bootstrap';
declare var $: any;
@Component({
  selector: 'app-modify',
  templateUrl: './modify.component.html',
  styleUrls: ['./modify.component.css']
})
export class ModifyComponent implements OnInit {

  model: any = {};
  openResult: any = {};

  constructor(private modifyService: ModifyService) { }

  ngOnInit() { }

   list1(){      
          this.modifyService.list1(this.model).subscribe((result: any) => {
                                    let res = result;                                    
                                    console.log("suc"+JSON.stringify(res));
                                   // this.result = result;
                                     this.model = result;
                                     
                                },
                                err => {
                                    console.log(err );
                                }
                         );;
       
    }

    modify(){
        this.modifyService.modify(this.model).subscribe((result: any) => {
                                    let res = result;  
                                    this.openResult = result;                                  
                                    $("#myModal2").modal('show');
                                     
                                },
                                err => {
                                    console.log(err );
                                }
                         );;
       
    }

    delete(){
        this.modifyService.delete(this.model).subscribe((result: any) => {
                                    let res = result;  
                                    this.openResult = result;                                  
                                   
                                    $("#myModal1").modal('show');
                                     
                                },
                                err => {
                                    console.log(err );
                                }
                         );;
    }

    bitmap(){
        this.modifyService.bitmap(this.model).subscribe();
    }

    refresh(): void {
      window.location.reload();
    }

}
