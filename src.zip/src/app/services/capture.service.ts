import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
declare var $: any;

import {DImageCaptureBO} from '../modals/DImageCaptureBO';

@Injectable()
export class CaptureService {

  constructor(private http: Http) { }

  open(imageCaptureBO: DImageCaptureBO){
        let result;

        let body = JSON.stringify(imageCaptureBO);
        let url = " http://10.146.166.13:8080/pbconversion/rest/CaptureImages";
        let headers = new Headers({ 'Content-Type': 'application/json'});
        
        //headers.append('Access-Control-Allow-Origin', 'http://localhost:8080');
        //headers.append('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
        //headers.append('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
      
        let options = new RequestOptions({ headers: headers, method: "post" });
       
       return this.http.post(url,body,options)
            .map(res => res.json()).catch((error:any) => Observable.throw(error.json().error || 'Server error')); //...errors if
                         
            
            
    }

      upload(imageCaptureBO: DImageCaptureBO){
        imageCaptureBO.imgpic = null;
        let body = JSON.stringify(imageCaptureBO);
        var url = "http://10.146.166.13:8080/pbconversion/rest/upload";
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, method: "post" });
        return this.http.post(url,body,options)
            .map(res => res.json());
            
    }


      bitmap(data: any){
     let body = JSON.stringify(data);
        var url = "http://10.146.166.16:8081/pbconversion/rest/CaptureImages";
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, method: "post" });
        return this.http.post(url,body,options)
            .map(res => res.json());
            
    }

}
