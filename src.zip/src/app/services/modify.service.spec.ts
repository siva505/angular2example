import { TestBed, inject } from '@angular/core/testing';

import { ModifyService } from './modify.service';

describe('ModifyService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ModifyService]
    });
  });

  it('should ...', inject([ModifyService], (service: ModifyService) => {
    expect(service).toBeTruthy();
  }));
});
