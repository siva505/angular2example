import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Injectable()
export class ModifyService {

  constructor(private http: Http) { }

   list1(DFetchCheckimageBO: any){
        DFetchCheckimageBO.makerdtime = null;
        DFetchCheckimageBO.checkerdtime = null;
        let body = JSON.stringify(DFetchCheckimageBO);
        var url = "  http://10.146.166.13:8080/pbconversion/rest/ModifyImages/list";
        let headers = new Headers({ 'Content-Type': 'application/json'});
        let options = new RequestOptions({ headers: headers, method: "post" });
       
      return this.http.post(url,body,options)
            .map(res => res.json()).catch((error:any) => Observable.throw(error.json().error || 'Server error'));//...errors if
      
    }

      modify(DFetchCheckimageBO: any){
        DFetchCheckimageBO.makerdtime = null;
        DFetchCheckimageBO.checkerdtime = null;
        let body = JSON.stringify(DFetchCheckimageBO);
        var url = "http://10.146.166.13:8080/pbconversion/rest/ModifyImages/modifiy";
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, method: "post" });
        return this.http.post(url,body,options)
                  .map(res => res.json()).catch((error:any) => Observable.throw(error.json().error || 'Server error'));//...errors if

    }


     delete(DFetchCheckimageBO: any){
        DFetchCheckimageBO.makerdtime = null;
        DFetchCheckimageBO.checkerdtime = null;
       
        let body = JSON.stringify(DFetchCheckimageBO);
        var url = "http://10.146.166.13:8080/pbconversion/rest/ModifyImages/delete";
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, method: "post" });
        return this.http.post(url,body,options)
                  .map(res => res.json()).catch((error:any) => Observable.throw(error.json().error || 'Server error'));//...errors if

    }


      bitmap(WImageDisplayBO: any){
        WImageDisplayBO.gUserId = null;
        WImageDisplayBO.lImgDescbefore = null;
        WImageDisplayBO.lOrigImgType = null;
        WImageDisplayBO.lSafeWordIDbefore = null;
        WImageDisplayBO . lImgTypebefore = null;
        let body = JSON.stringify(WImageDisplayBO);
        var url = "http://10.146.166.16:8081/pbconversion/rest/Auth/bitmap";
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, method: "post" });
        return this.http.post(url,body,options)
           .map(res => res.json()).catch((error:any) => Observable.throw(error.json().error || 'Server error'));//...errors if

    }
}
