import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Injectable()
export class AuthorizeService {

  constructor(private http: Http) { }
   list(WImageAuthBO: any){
        WImageAuthBO.gUserId = null;
        WImageAuthBO.lImgDescbefore = null;
        WImageAuthBO.lOrigImgType = null;
        WImageAuthBO.lSafeWordIDbefore = null;
        WImageAuthBO . lImgTypebefore = null;
        let body = JSON.stringify(WImageAuthBO);
        let url = "  http://10.146.166.13:8080/pbconversion/rest/Auth/list";
        let headers = new Headers({ 'Content-Type': 'application/json'});
       let options = new RequestOptions({ headers: headers, method: "post" });
       
       return this.http.post(url,body,options)
            .map(res => res.json()).catch((error:any) => Observable.throw(error.json().error || 'Server error'));//...errors if
      
    }

      authorize(WImageAuthBO: any){
        WImageAuthBO.gUserId = null;
        WImageAuthBO.lImgDescbefore = null;
        WImageAuthBO.lOrigImgType = null;
        WImageAuthBO.lSafeWordIDbefore = null;
        WImageAuthBO . lImgTypebefore = null;
        let body = JSON.stringify(WImageAuthBO);
        var url = "http://10.146.166.13:8080/pbconversion/rest/Auth/authorize";
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, method: "post" });
        return this.http.post(url,body,options)
                  .map(res => res.json()).catch((error:any) => Observable.throw(error.json().error || 'Server error'));//...errors if

    }


     reject(WImageAuthBO: any){
        WImageAuthBO.gUserId = null;
        WImageAuthBO.lImgDescbefore = null;
        WImageAuthBO.lOrigImgType = null;
        WImageAuthBO.lSafeWordIDbefore = null;
        WImageAuthBO . lImgTypebefore = null;
        let body = JSON.stringify(WImageAuthBO);
        var url = "http://10.146.166.13:8080/pbconversion/rest/Auth/reject";
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, method: "post" });
        return this.http.post(url,body,options)
                  .map(res => res.json()).catch((error:any) => Observable.throw(error.json().error || 'Server error'));//...errors if

    }


      bitmap(WImageAuthBO: any){
        WImageAuthBO.gUserId = null;
        WImageAuthBO.lImgDescbefore = null;
        WImageAuthBO.lOrigImgType = null;
        WImageAuthBO.lSafeWordIDbefore = null;
        WImageAuthBO . lImgTypebefore = null;
        let body = JSON.stringify(WImageAuthBO);
        var url = "http://10.146.166.13:8080/pbconversion/rest/Auth/bitmap";
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, method: "post" });
        return this.http.post(url,body,options)
           .map(res => res.json()).catch((error:any) => Observable.throw(error.json().error || 'Server error'));//...errors if

    }
}
