import { Component, OnInit } from '@angular/core';
import {AuthorizeService} from '../services/authorize.service';
declare var $: any;
@Component({
  selector: 'app-authorize',
  templateUrl: './authorize.component.html',
  styleUrls: ['./authorize.component.css']
})
export class AuthorizeComponent implements OnInit {

   model: any = {};
   openResult: any = {};
  constructor(public authorizeService: AuthorizeService ) { }

  ngOnInit() {
  }


    list(){      
         this.authorizeService.list(this.model).subscribe((result: any) => {
                                    let res = result;                                    
                                    console.log("suc"+JSON.stringify(res));
                                   // this.result = result;
                                     this.model = result;
                                     
                                },
                                err => {
                                    console.log(err );
                                }
                         );;
       
    }

    authorize(){
        this.authorizeService.authorize(this.model).subscribe((result: any) => {
                                    let res = result;  
                                    this.openResult = result;                                  
                                    $("#myModal2").modal('show');
                                     
                                },
                                err => {
                                    console.log(err );
                                }
                         );;
       
    }

    reject(){
        this.authorizeService.reject(this.model).subscribe((result: any) => {
                                    let res = result;  
                                    this.openResult = result;                                  
                                    $("#myModal2").modal('show');
                                     
                                },
                                err => {
                                    console.log(err );
                                }
                         );;
    }

    bitmap(){
        this.authorizeService.bitmap(this.model).subscribe();
    }

    refresh(): void {
      window.location.reload();
    }

}
