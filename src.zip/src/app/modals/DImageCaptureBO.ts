export interface DImageCaptureBO {
    imgid: string;
    imgdesc: string;
    imgtype:string;
    safewordid: string;
    imgfile : string;
    imgpic : string;
}